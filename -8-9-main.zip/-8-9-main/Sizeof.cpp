#include <iostream>
using namespace std;

int main()
{
    int x = 3;
    cout << sizeof(int) << endl;
    cout << sizeof(x * 10) << endl;
    cout << sizeof(x * 0.1) << endl;
    return 0;
}