#include <iostream>
using namespace std;

int main()
{
    int x = 3, y = 4;
    cout << ++x << "\t" << --y << endl;
    cout << x++ << "\t" << y-- << endl;
    cout << x << "\t" << y << endl;
    return 0;
}